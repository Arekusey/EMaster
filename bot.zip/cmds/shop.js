const Discord = require('discord.js')
const fs = require('fs')
const shop = require('../shop.json')

module.exports.run = async (client, message, args) => {
    let u = message.author.id;
    await message.delete();
    let embed = new Discord.RichEmbed()
        .setTitle('Магазин')
        .setColor("RANDOM")
        .setDescription("Здесь вы можете преобрести необходимый товар\nДля подробностей e?ii [name item]")
        .setFooter(`ID: ${u} || Ds.bot v2.0`)
        .addField(`${client.emojis.find(emoji => emoji.name === "crystal")} 30000 - VIP`, `Покупка роли VIP. Роль для Доступа ко всем комнатам`,true)
        .addField(`${client.emojis.find(emoji => emoji.name === "crystal")} 15000 - DjRole`,`Получения роли DJ для доступа к командам муз.бота`,true)
        .addField(`${client.emojis.find(emoji => emoji.name === "crystal")} 8000 - GodMode`,`Покупка роли GodMode для уникального цвета в чате.`,true)
        .addField(`${client.emojis.find(emoji => emoji.name === "crystal")} 15000 - Комната`,`Покупка собственной комнаты на сервере`,true)
        .addField(`${client.emojis.find(emoji => emoji.name === "crystal")} 10000 - smile`,`Добавление своего смалика на сервер ( +анимированные )`,true)
        .addField(`${client.emojis.find(emoji => emoji.name === "crystal")} 5000 - Размут`,`Покупка размута своего аккаунта.`,true)
    message.channel.send(embed)
}

module.exports.help = {
    name: "shop"
}