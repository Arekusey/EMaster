const Discord = require('discord.js')

module.exports.run = async (client,message,args) => {
    let embed = new Discord.RichEmbed()
        .setAuthor(message.guild.member(message.author.id).displayName, message.author.avatarURL)
        .setColor("RANDOM")
        .setDescription(`Вот что я умею делать: `)
        .setFooter(`Help || Ds.bot v2.0`)
        .setTimestamp()
        .addField(`-game [command]`,`Игровые команды. Для просмотра помощи смотрите -help game`,false)
        .addField(`-bi [item_name]`,`Покупка предметов.`,false)
        .addField(`-dwarn, -swarn, -listw`,`Система варнов`,false)
        .addField(`-ii [item_name]`,`Информация о предмете`,false)
        .addField(`-shop`,`Список предметов`,false)
        .addField(`-useri <@mention>`,`Статистика игрока`,false)
        .addField(`-ver [@mention]`,`Дать достук к комнате #✔заявки™©`,false)
        .addField(`-v [sum] [quest]`,`Викторина на деньги`,false)
    message.channel.send(embed)
}

module.exports.help = {
    name: "help"
}