const Discord = require('discord.js')
const fs = require('fs')
const profile = require('../profile.json')

module.exports.run = async (client,message,args) => {
    arg = args.slice(1);
    if(args[0] === 'am'){
        if(!message.member.hasPermission("ADMINISTRATOR")) return;
        let member = message.guild.member(message.mentions.users.first() || message.guild.members.get(args[1]))
	    await message.delete()
        let argsUser
        if (member) argsUser = member.user
        else argsUser = message.author
        profile[argsUser.id].coin = parseInt(profile[argsUser.id].coin) + parseInt(args[2])
        fs.writeFile('./profile.json',JSON.stringify(profile),(err) => {
            if(err) console.log(err)
        })
        message.channel.send(`${client.emojis.find(emoji => emoji.name === "yes")} Success!`)
    }

    if(args[0] === 'rm') {
        if(!message.member.hasPermission("ADMINISTRATOR")) return;
        let member = message.guild.member(message.mentions.users.first() || message.guild.members.get(args[1]))
        let argsUser
        if (member) argsUser = member.user
        else argsUser = message.author
        profile[argsUser.id].coin = parseInt(profile[argsUser.id].coin) - parseInt(args[2])
        fs.writeFile('./profile.json', JSON.stringify(profile),(err)=>{
            if(err) console.log(err)
        })
        message.channel.send(`${client.emojis.find(emoji => emoji.name === "yes")} Success!`)
    }

    if(args[0] === 'bal') {
        let embed = new Discord.RichEmbed()
            .setAuthor(message.guild.member(message.author.id).displayName,message.author.avatarURL)
            .setColor("RANDOM")
            .setDescription(`Баланс: ${profile[message.author.id].coin} ${client.emojis.find(emoji => emoji.name === "crystal")}`)
            .setFooter("Money Balance || Ds.bot v2.0")
        message.channel.send(embed)
    }

    if(args[0] === 'rep-'){
        let member = message.guild.member(message.mentions.users.first() || message.guild.members.get(args[1]))
        let au
        if(member) au = member.user
        else au = message.author
        await message.delete()
        let u = profile[au.id]
        if(!u.repl[message.author.id] == '') {
            u.rep--;
            u.repl[message.author.id] = '';
            fs.writeFile('./profile.json', JSON.stringify(profile),(err) => {
                if (err) console.log(err)
            })
            message.channel.send(`Успешно понижена репутация игроку ${au}`)
        } else {
            message.channel.send(`Вы еще не ставили репутацию ${au}`)
        }
    }

    if(args[0] === 'rep+'){
        let member = message.guild.member(message.mentions.users.first() || message.guild.members.get(args[0]))
        let au
        if(member) au = member.user
        else au = message.author
        await message.delete()
        let u = profile[au.id]
        if(!u.repl[message.author.id] || u.repl[message.author.id] == '') {
            u.rep++;
            u.repl[message.author.id] = 'set';
            fs.writeFile('./profile.json', JSON.stringify(profile),(err) => {
                if (err) console.log(err)
            })
            message.channel.send(`Успешно повышена репутация игроку ${au}`)
        } else {
            message.channel.send(`Вы уже ставили репутацию ${au}`)
        }
    }
}

module.exports.help = {
    name: "game"
}